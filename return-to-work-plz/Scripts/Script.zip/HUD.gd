extends CanvasLayer

## HUD — Main UI overlay.
## Shows Productivity, Morale, and Current Task.

@onready var productive_texture: TextureRect = $ProductivityContainer/ProductiveTexture
@onready var moral_texture: TextureRect = $MoraleContainer/MoralTexture
@onready var productivity_bar: TextureProgressBar = $ProductivityContainer/Bar
@onready var morale_bar: TextureProgressBar = $MoraleContainer/Bar
@onready var task_bg: TextureRect = $TaskBackground
@onready var task_label: Label = $TaskBackground/TaskLabel
@onready var clockout_label: Label = $ClockOutLabel

var deadline_label: Label = null
var direction_arrow: Label = null  ## Flashing arrow CTA pointing toward task room
var _cta_tween: Tween = null

# Slot order on each floor for direction logic
const FLOOR1_SLOTS = ["Slot_F1_Left", "Slot_Elevator_F1", "Slot_F1_Right"]
const FLOOR2_SLOTS = ["Slot_F2_Left", "Slot_F2_Middle", "Slot_Elevator_F2", "Slot_F2_Right", "Slot_F2_FarRight"]

# Maps task room name → which floor slots to search
const TASK_ROOM_TO_SLOT: Dictionary = {
	"Lobby": "Slot_F1_Left",
	"Lounge": "Slot_F2_Left",
	"Printer": "Slot_F2_FarRight",
	"Meeting": "Slot_F2_Right",
}

var texbox_task: Texture2D = preload("res://Assets/UI V4/TEXTBOX/TASK.png")
const productive_mid = preload("res://Assets/UI V4/PRODUCTIVITY BAR/BAR/ALERT.png")
const productive_bad = preload("res://Assets/UI V4/PRODUCTIVITY BAR/BAR/BAD.png")
const productive_good = preload("res://Assets/UI V4/PRODUCTIVITY BAR/BAR/GOOD.png")
var moral_good: Texture2D = preload("res://Assets/UI V4/MORAL/MORAL/GOOD.png")
var moral_mid: Texture2D = preload("res://Assets/UI V4/MORAL/MORAL/ALERT.png")
var moral_bad: Texture2D = preload("res://Assets/UI V4/MORAL/MORAL/BAD.png")

var _animating: bool = false

func _ready() -> void:
	GameManager.objective_completed.connect(_on_objective_completed)
	GameManager.all_objectives_completed.connect(_on_all_completed)
	GameManager.loop_restarted.connect(_on_loop_restarted)
	GameManager.npc_talk_updated.connect(_on_npc_talk_updated)
	GameManager.morale_changed.connect(_on_morale_changed)
	GameManager.productivity_changed.connect(_on_productivity_changed)
	GameManager.current_task_changed.connect(_on_current_task_changed)
	if has_node("/root/RoomManager"):
		RoomManager.room_changed.connect(_on_room_changed)
	
	clockout_label.visible = false
	_show_current_task()
	
	# Init bars
	_on_morale_changed(GameManager.morale)
	_on_productivity_changed(GameManager.productivity)
	
	# Create Deadline Label dynamically
	deadline_label = Label.new()
	deadline_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	deadline_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	deadline_label.offset_top = 40
	deadline_label.add_theme_font_size_override("font_size", 36)
	deadline_label.add_theme_color_override("font_color", Color(0.8, 0.1, 0.1))
	add_child(deadline_label)
	
	# Create directional arrow indicator
	direction_arrow = Label.new()
	direction_arrow.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	direction_arrow.offset_left = 30
	direction_arrow.offset_top = -40
	direction_arrow.offset_right = 200
	direction_arrow.offset_bottom = 40
	direction_arrow.add_theme_font_size_override("font_size", 64)
	direction_arrow.add_theme_color_override("font_color", Color(1.0, 0.85, 0.0))
	direction_arrow.text = ""
	direction_arrow.visible = false
	add_child(direction_arrow)
	
	_update_direction_arrow()

func _process(_delta: float) -> void:
	if not deadline_label: return
	
	if GameManager.is_deadline_active:
		if InconvenienceManager.is_clock_stopped:
			# Freeze the text
			pass
		else:
			var t = maxf(GameManager.task_deadline_time, 0.0)
			deadline_label.text = "TIME REMAINING: %.1fs" % t
	else:
		deadline_label.text = ""

func _on_current_task_changed(_idx: int) -> void:
	_update_direction_arrow()

func _on_room_changed(_room_name: String) -> void:
	_update_direction_arrow()

## Work out which direction the current task room is relative to the player's current room,
## then show a flashing yellow arrow. Hide it if the task is in the current room.
func _update_direction_arrow() -> void:
	if not direction_arrow: return
	
	var task_idx = GameManager.current_task_index
	if task_idx >= GameManager.objectives.size():
		_stop_cta_flash()
		direction_arrow.visible = false
		return
	
	var task_room: String = GameManager.objectives[task_idx].get("room", "")
	
	# "Any" or "Cubicle" tasks — hide arrow (could be current room or multiple rooms)
	if task_room == "Any" or task_room == "Cubicle":
		_stop_cta_flash()
		direction_arrow.visible = false
		return
	
	# Find which slot the task room is currently assigned to
	var target_slot = ""
	for slot in RoomManager.current_layout:
		if RoomManager.current_layout[slot] == task_room:
			target_slot = slot
			break
	
	if target_slot == "":
		_stop_cta_flash()
		direction_arrow.visible = false
		return
	
	# If already in the right room, hide arrow
	if target_slot == RoomManager.current_slot:
		_stop_cta_flash()
		direction_arrow.visible = false
		return
	
	# Determine direction by comparing slot indices on the same floor
	var active_slots = FLOOR1_SLOTS if RoomManager.current_floor == 1 else FLOOR2_SLOTS
	var current_idx = active_slots.find(RoomManager.current_slot)
	var target_idx = active_slots.find(target_slot)
	
	# Target on a different floor — still show an arrow; default right toward elevator
	if target_idx == -1:
		direction_arrow.text = "→"
		direction_arrow.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
		direction_arrow.offset_right = -30
		direction_arrow.offset_left = -170
	elif target_idx < current_idx:
		direction_arrow.text = "←"
		direction_arrow.set_anchors_preset(Control.PRESET_CENTER_LEFT)
		direction_arrow.offset_left = 30
		direction_arrow.offset_right = 200
	else:
		direction_arrow.text = "→"
		direction_arrow.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
		direction_arrow.offset_right = -30
		direction_arrow.offset_left = -170
	
	direction_arrow.offset_top = -40
	direction_arrow.offset_bottom = 40
	direction_arrow.visible = true
	_start_cta_flash()

func _start_cta_flash() -> void:
	if _cta_tween and _cta_tween.is_valid():
		return  # Already flashing
	_cta_tween = create_tween().set_loops()
	_cta_tween.tween_property(task_bg, "modulate:a", 0.4, 0.45).set_ease(Tween.EASE_IN_OUT)
	_cta_tween.tween_property(task_bg, "modulate:a", 1.0, 0.45).set_ease(Tween.EASE_IN_OUT)

func _stop_cta_flash() -> void:
	if _cta_tween and _cta_tween.is_valid():
		_cta_tween.kill()
		_cta_tween = null
	if task_bg:
		task_bg.modulate.a = 1.0

func _on_morale_changed(val: float) -> void:
	var tween = create_tween()
	tween.tween_property(morale_bar, "value", val, 0.3).set_ease(Tween.EASE_OUT)
	
	if val < 33.0:
		moral_texture.texture = moral_bad
	elif val > 66.0:
		moral_texture.texture = moral_good
	else:
		moral_texture.texture = moral_mid

func _on_productivity_changed(val: float) -> void:
	var tween = create_tween()
	tween.tween_property(productivity_bar, "value", val, 0.3).set_ease(Tween.EASE_OUT)

	
	if val < 33.0:
		productive_texture.texture = productive_bad
	elif val > 66.0:
		productive_texture.texture = productive_good
	else:
		productive_texture.texture = productive_mid
func _on_objective_completed(_task_id: String) -> void:
	_animate_task_complete()

func _on_all_completed() -> void:
	clockout_label.visible = true

func _on_loop_restarted(_loop_number: int) -> void:
	clockout_label.visible = false
	task_bg.position.x = 1550.0
	_stop_cta_flash()
	_show_current_task()
	_update_direction_arrow()

func _on_npc_talk_updated(_count: int) -> void:
	if not _animating and GameManager.get_current_task_id() == "talk_npcs":
		_refresh_task_text()

func _get_task_display_text(idx: int) -> String:
	if idx >= GameManager.objectives.size():
		return ""
	var obj = GameManager.objectives[idx]
	var label_text = obj["label"]
	if obj["id"] == "talk_npcs":
		label_text = "Talk to coworkers (%d/%d)" % [GameManager.get_talked_count(), GameManager.REQUIRED_NPC_TALKS]
	return "Task %d/%d - %s" % [idx + 1, GameManager.get_total_count(), label_text]

func _update_task_texture() -> void:
	# If text is long, use big texture, else small
	# A typical short task is ~25 chars including bbcode tags
	pass
func _refresh_task_text() -> void:
	var idx = GameManager.current_task_index
	task_label.text = _get_task_display_text(idx)
	_update_task_texture()

func _show_current_task() -> void:
	var idx = GameManager.current_task_index
	if idx >= GameManager.objectives.size():
		task_label.text = ""
		task_bg.visible = false
		return
	
	task_bg.visible = true
	task_label.text = _get_task_display_text(idx)
	_update_task_texture()
	
	task_bg.position.x = 1920.0
	var tween = create_tween()
	tween.tween_property(task_bg, "position:x", 1500.0, 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

func _animate_task_complete() -> void:
	if _animating:
		return
	_animating = true
	
	var idx = GameManager.current_task_index - 1
	if idx < 0 or idx >= GameManager.objectives.size():
		_animating = false
		return
	
	task_label.text = "DONE - %s" % _get_task_display_text(idx)
	
	var tween = create_tween()
	tween.tween_interval(0.8)
	tween.tween_property(task_bg, "position:x", 1550.0, 0.35).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_BACK)
	tween.tween_callback(_on_slide_out_done)

func _on_slide_out_done() -> void:
	_animating = false
	if GameManager.current_task_index >= GameManager.objectives.size():
		task_bg.visible = false
		_stop_cta_flash()
	else:
		_show_current_task()
		_update_direction_arrow()
